package Prog1a;
import java.util.Scanner;

public class EvenNumbers {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		System.out.println(" ");
		System.out.println("Enter number to find even numbers less than or equal to it"); 
		int n;
		Scanner in =new Scanner(System.in);
		n=in.nextInt();
		System.out.println("Even numbers between 1 to "+n+" are:");
		for(int i=1;i<=n;i++) {
			if(i%2==0) {
				System.out.println(i+"");
				
			}
		}

	}

}
package prog1d;
import java.util.Scanner;

public class Perimeters {

 private int width = 0, length = 0;

 public Perimeters (int width, int length)
  {
   setWidth(width);
   setLength(length);
  }
  void setWidth(int width)
  {
   this.width = width;
  }
  int getWidth()
  {
   return this.width;
  }
  void setLength(int length)
  {
   this.length = length;
  }
  
  int getLength()
  {
   return this.length;
  }
  int getPerimeter()
  {
   return 2*getWidth() + 2*getLength();
  }
  int getArea()
  {
   return getWidth()*getLength();
  }
 
 public static void main(String[] args)
 {
  @SuppressWarnings("resource")
  Scanner scan = new Scanner(System.in);
  System.out.println("Enter width:"); int width=scan.nextInt();
  System.out.println("Enter length:"); int length=scan.nextInt();
  Perimeters rect = new Perimeters(width, length);
  System.out.println("Area: " + rect.getArea()+"\r\n");
  System.out.println("Perimeter: " + rect.getPerimeter()+"\r\n");
 }
}
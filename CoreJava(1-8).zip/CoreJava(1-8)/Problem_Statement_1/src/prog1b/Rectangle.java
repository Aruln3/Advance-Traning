package prog1b;

import java.util.Scanner;

public class Rectangle {
    float area;
    public Rectangle(float length,float width) {
     area=length*width;
    System.out.println(" ");
    System.out.println("Rectangle Info : ");
    
    System.out.println("Length = " +length);
    System.out.println("Width = " +width);
    System.out.println("area of the rectangle is :"+area);
	}
    public static class TestRectangle {

    	@SuppressWarnings("unused")
		public static void main(String[] args) {
    		float []length=new float[5];
    	    float []width=new float[5];
    		System.out.println("enter length of 5 Rectangle ");
    		Scanner scan = new Scanner(System.in);
    		for(int index = 0; index < 5; index++) {
    			length[index] = scan.nextFloat();
    			}
    		System.out.println("enter width of 5 Rectangle ");
    		for(int index = 0; index < 5; index++) {
    			width[index] = scan.nextFloat();
    		}
    		scan.close();
			Rectangle obj1=new Rectangle(length[0], width[0]);
			Rectangle obj2=new Rectangle(length[1], width[1]);
    		Rectangle obj3=new Rectangle(length[2], width[2]);
    	    Rectangle obj4=new Rectangle(length[3], width[3]);
    		Rectangle obj5=new Rectangle(length[4], width[4]);
    	}
    }

}
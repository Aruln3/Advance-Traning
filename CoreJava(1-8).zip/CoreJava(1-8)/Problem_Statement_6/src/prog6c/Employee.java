package prog6c;

class Employee {
    private String empno;
    private String name;
    private String empaddress;
    
    /**
     * Employee constructor
     */
    public Employee(String empno, String name,String empaddress) { // constructor
           this.empno = empno;
           this.name = name;
           this.empaddress=empaddress;
    }
 
    @Override
    public String toString() {
    	System.out.println("\n Employee Info:");
           return " empno = " + empno + "\n name = " + name + "\n address = " + empaddress + "\n";
    }   
}
 
//Exception to indicate that LinkedList is empty.
 
@SuppressWarnings("serial")
class LinkedListEmptyException extends RuntimeException{
       public LinkedListEmptyException(){
         super();
       }
      
     public LinkedListEmptyException(String message){
         super(message);
       }  
}
  //Node class, which holds data and contains next which points to next Node.
class Node<T> {
    public T data; 
    public Node<T> next; 
    public Node(T data){
           this.data = data;
    }
    public void displayNode() {
           System.out.print( data + " ");
    }
}
 //* Singly LinkedList class (Generic implementation)
class LinkedList<T> {
    private Node<T> first; // ref to first link on list
    /**
     * LinkedList constructor
     */
    public LinkedList(){
           first = null;
    }

    public void insertFirst(T data) {
           Node<T> newNode = new Node<T>(data);  //Creation of New Node.
           newNode.next = first;   //newLink ---> old first
           first = newNode;  //first ---> newNode
    }
    
    //Display LinkedList
    
    public void displayLinkedList() {
           System.out.print("Displaying LinkedList [first--->last]: \n ");
           Node<T> tempDisplay = first; // start at the beginning of linkedList
           while (tempDisplay != null){ // Executes until we don't find end of list.
                  tempDisplay.displayNode();
                  tempDisplay = tempDisplay.next; // move to next Node
           }
           System.out.println();      
    }
    
    public static void main(String[] args) {
        LinkedList<Employee> linkedList = new LinkedList<Employee>(); // creation of Linked List
        linkedList.insertFirst(new Employee("11", "Arul","XXX"));
        linkedList.insertFirst(new Employee("12", "Abisekh","YYY"));
        linkedList.insertFirst(new Employee("13", "Kamesh","ZZZ"));
        linkedList.insertFirst(new Employee("14", "Pradeep","AAA"));
        linkedList.insertFirst(new Employee("15", "Sidhviik","BBB"));

        linkedList.displayLinkedList(); // display LinkedList
  }
}
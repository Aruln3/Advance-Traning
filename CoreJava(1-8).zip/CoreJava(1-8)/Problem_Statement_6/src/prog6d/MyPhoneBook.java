package prog6d;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.InputStreamReader;
public class MyPhoneBook{
	static void solve()
	{
	    BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	    ArrayList<String> Names=new ArrayList<String>();
	    int option=-1;
	    try{
	    while(option!=3)
	    {
	        System.out.println("\nEnter the option\n1.Add a number\n2.Check a number\n3.Exit");
	        option=Integer.parseInt(br.readLine());
	        switch(option)
	        {
	            case 1:
	            {
	                System.out.println("Enter the name :");
	                String temp=br.readLine();
	                Names.add(temp);
	                System.out.println("Enter the number :");
	                String temp1=br.readLine();
	                Names.add(temp1);
	                System.out.println(temp+"'s number " +temp1+" added to List");
	                break;
	            }
	            case 2:
	            {
	                System.out.println("Enter the name to he search number :");
	                String temp=br.readLine();
					if(Names.indexOf(temp)>=0)
	                System.out.println(temp+" is present in List, number is ");
	                else System.out.println(temp+" is not found in List");
	                break;
	            }
	        }
	    }
	    }
	    catch(Exception e)
	    {
	        System.out.println(e);
	    }
	    finally
	    {
	        System.out.println("Program Complete");
	    }
	}
	public static void main(String[] args) {
		solve();
	}
}
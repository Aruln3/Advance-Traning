package prog16a;

import java.util.Scanner;

class ClimbingStairs { 
    static int fib(int n)
    {
        if (n <= 1)
            return n;
        return fib(n - 1) + fib(n - 2);
    }
    static int countWays(int s)
    {
        return fib(s + 1);
    }
       public static void main(String args[]) {
    	@SuppressWarnings("resource")
		Scanner scanner=new Scanner(System.in);
    System.out.println("\nEnter the Number of STEPS");
    int n=scanner.nextInt();
    {        
        System.out.println("\nNumber of ways you can climb to the top = " + countWays(n));
    }
} }